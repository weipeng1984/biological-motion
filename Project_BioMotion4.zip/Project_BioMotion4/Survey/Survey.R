
# To process the survey

library(tidyverse)

# reading survey data
df_survey <- read.csv(file.choose(), header = TRUE, sep = ',')

# reading ID March results to get the valid session id
MyData <- read.csv(file.choose(), header = TRUE, sep = ',')

# attach(df_survey)

df_survey <- subset(df_survey, df_survey$Response.ID %in% MyData$Response_ID)


names(df_survey)[1] <- 'Response_ID'
names(df_survey)[8] <- 'IP'
names(df_survey)[10] <- 'Prolific_ID'
names(df_survey)[11] <- 'Country'
names(df_survey)[12] <- 'Gender'
names(df_survey)[13] <- 'Age'
names(df_survey)[14] <- 'F01'
names(df_survey)[15] <- 'F02'
names(df_survey)[16] <- 'F03'
names(df_survey)[17] <- 'F04'
names(df_survey)[18] <- 'F05'
names(df_survey)[19] <- 'F06'
names(df_survey)[20] <- 'F07'
names(df_survey)[21] <- 'F08'
names(df_survey)[22] <- 'F09'
names(df_survey)[23] <- 'F10'
names(df_survey)[24] <- 'F11'
names(df_survey)[25] <- 'F12'
names(df_survey)[26] <- 'F13'
names(df_survey)[27] <- 'F14'
names(df_survey)[28] <- 'F15'
names(df_survey)[30] <- 'L01'
names(df_survey)[32] <- 'L02'
names(df_survey)[34] <- 'L03'
names(df_survey)[36] <- 'L04'
names(df_survey)[38] <- 'L05'
names(df_survey)[40] <- 'L06'
names(df_survey)[42] <- 'L07'
names(df_survey)[44] <- 'L08'
names(df_survey)[46] <- 'L09'
names(df_survey)[48] <- 'L10'
names(df_survey)[50] <- 'L11'


df_survey <- subset(df_survey, select = c(1, 8, 10:50))

# unify answer option

gender <- as.character(df_survey$Gender)

for (i in gender) {
  if (i == 'female') {
    gender[gender == 'female'] = 'f'
  } else if (i == 'Female') {
    gender[gender == 'Female'] = 'f'
  } else if (i == 'F') {
    gender[gender == 'F'] = 'f'
  } else if (i == 'FEMALE') {
    gender[gender == 'FEMALE'] = 'f'
  } else if (i == 'Feminino') {
    gender[gender == 'Feminino'] = 'f'
  } else if (i == 'Femmina') {
    gender[gender == 'Femmina'] = 'f'
  } else if (i == 'Famale') {
    gender[gender == 'Famale'] = 'f'
  } else if (i == 'male') {
    gender[gender == 'male'] = 'm'
  } else if (i == 'Male') {
    gender[gender == 'Male'] = 'm'
  } else if (i == 'MALE') {
    gender[gender == 'MALE'] = 'm'
  } else if (i == 'man') {
    gender[gender == 'man'] = 'm'
  } else if (i == 'men') {
    gender[gender == 'men'] = 'm'
  } else if (i == 'women') {
    gender[gender == 'women'] = 'f'
  } else if (i == 'Male ') {
    gender[gender == 'Male '] = 'm'
  } else if (i == 'Female ') {
    gender[gender == 'Female '] = 'f'
  } else if (i == 'Fem') {
    gender[gender == 'Fem'] = 'f'
  } else if (i == 'female ') {
    gender[gender == 'female '] = 'f'
  } else {
    print('Please check all the levels manually!')
  }
  #return(gender)
}

df_survey$Gender <- gender

# calculate the free will beliefs (don't reverse the Determinism sub-scale)
# dimension of the data.frame


for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_survey)[2]) {
    if (df_survey[i, j] == 'Strongly disagree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly disagree'] = 1
    } else if (df_survey[i, j] == 'Disagree') {
      df_survey[i, j][df_survey[i, j] == 'Disagree'] = 2
    } else if (df_survey[i, j] == 'Somewhat disagree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat disagree'] = 3
    } else if (df_survey[i, j] == 'Neither agree nor disagree') {
      df_survey[i, j][df_survey[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df_survey[i, j] == 'Somewhat agree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat agree'] = 5
    } else if (df_survey[i, j] == 'Agree') {
      df_survey[i, j][df_survey[i, j] == 'Agree'] = 6
    } else if (df_survey[i, j] == 'Strongly agree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly agree'] = 7
    }
  }
}


fw <- c(7, 10, 13, 16, 19)
de <- c(8, 11, 14, 17, 20)
du <- c(9, 12, 15, 18, 21)

# calculating the free will beliefs

df_survey$fw <- rowSums(sapply(df_survey[, fw], as.numeric))

# calculating the Determinism

df_survey$de <- rowSums(sapply(df_survey[, de], as.numeric))

# calculating the dualism sub-scale

df_survey$du <- rowSums(sapply(df_survey[, du], as.numeric))

# sum the total score for each participant

df_survey$fwi <- rowSums(sapply(df_survey[, 7:21], as.numeric))



################################################################################
# Now starts to process locus of control
# item 1


for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 22] == "Many of the unhappy things in people's lives are partly due to bad luck."
      & df_survey[i, 23] == 'Slightly well') {
    df_survey[i, 23][df_survey[i, 23] == 'Slightly well'] = 3
  } else if (df_survey[i, 22] == "Many of the unhappy things in people's lives are partly due to bad luck."
    & df_survey[i, 23] == 'Very well') {
    df_survey[i, 23][df_survey[i, 23] == 'Very well'] = 4
  } else if (df_survey[i, 22] == "People's misfortunes result from the mistakes they make."
             & df_survey[i, 23] == 'Slightly well') {
    df_survey[i, 23][df_survey[i, 23] == 'Slightly well'] = 1
  } else if (df_survey[i, 22] == "People's misfortunes result from the mistakes they make."
             & df_survey[i, 23] == 'Very well') {
    df_survey[i, 23][df_survey[i, 23] == 'Very well'] = 2
  }
}

# item 2

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 24] == "Unfortunately, an individual's worth often passes unrecognized no matter how hard he tries."
      & df_survey[i, 25] == 'Slightly well') {
    df_survey[i, 25][df_survey[i, 25] == 'Slightly well'] = 3
  } else if (df_survey[i, 24] == "Unfortunately, an individual's worth often passes unrecognized no matter how hard he tries."
             & df_survey[i, 25] == 'Very well') {
    df_survey[i, 25][df_survey[i, 25] == 'Very well'] = 4
  } else if (df_survey[i, 24] == 'In the long run, people get the respect they deserve in this world.'
             & df_survey[i, 25] == 'Slightly well') {
    df_survey[i, 25][df_survey[i, 25] == 'Slightly well'] = 1
  } else if (df_survey[i, 24] == 'In the long run, people get the respect they deserve in this world.'
             & df_survey[i, 25] == 'Very well') {
    df_survey[i, 25][df_survey[i, 25] == 'Very well'] = 2
  }
}

# item 3

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 26] == 'Without the right breaks, one cannot be an effective leader.'
      & df_survey[i, 27] == 'Slightly well') {
    df_survey[i, 27][df_survey[i, 27] == 'Slightly well'] = 3
  } else if (df_survey[i, 26] == 'Without the right breaks, one cannot be an effective leader.'
             & df_survey[i, 27] == 'Very well') {
    df_survey[i, 27][df_survey[i, 27] == 'Very well'] = 4
  } else if (df_survey[i, 26] == 'Capable people who fail to become leaders have not taken advantage of their opportunities.'
             & df_survey[i, 27] == 'Slightly well') {
    df_survey[i, 27][df_survey[i, 27] == 'Slightly well'] = 1
  } else if (df_survey[i, 26] == 'Capable people who fail to become leaders have not taken advantage of their opportunities.'
             & df_survey[i, 27] == 'Very well') {
    df_survey[i, 27][df_survey[i, 27] == 'Very well'] = 2
  }
}


# item 4

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 28] == 'Getting a good job depends mainly on being in the right place at the right time.'
      & df_survey[i, 29] == 'Slightly well') {
    df_survey[i, 29][df_survey[i, 29] == 'Slightly well'] = 3
  } else if (df_survey[i, 28] == 'Getting a good job depends mainly on being in the right place at the right time.'
             & df_survey[i, 29] == 'Very well') {
    df_survey[i, 29][df_survey[i, 29] == 'Very well'] = 4
  } else if (df_survey[i, 28] == 'Becoming a success is a matter of hard work; luck has little or nothing to do with it.'
             & df_survey[i, 29] == 'Slightly well') {
    df_survey[i, 29][df_survey[i, 29] == 'Slightly well'] = 1
  } else if (df_survey[i, 28] == 'Becoming a success is a matter of hard work; luck has little or nothing to do with it.'
             & df_survey[i, 29] == 'Very well') {
    df_survey[i, 29][df_survey[i, 29] == 'Very well'] = 2
  }
}

# item 5

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 30] == "Sometimes I feel that I don't have enough control over the direction my life is taking."
      & df_survey[i, 31] == 'Slightly well') {
    df_survey[i, 31][df_survey[i, 31] == 'Slightly well'] = 3
  } else if (df_survey[i, 30] == "Sometimes I feel that I don't have enough control over the direction my life is taking."
             & df_survey[i, 31] == 'Very well') {
    df_survey[i, 31][df_survey[i, 31] == 'Very well'] = 4
  } else if (df_survey[i, 30] == 'What happens to me is my own doing.'
             & df_survey[i, 31] == 'Slightly well') {
    df_survey[i, 31][df_survey[i, 31] == 'Slightly well'] = 1
  } else if (df_survey[i, 30] == 'What happens to me is my own doing.'
             & df_survey[i, 31] == 'Very well') {
    df_survey[i, 31][df_survey[i, 31] == 'Very well'] = 2
  }
}

# item 6

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 32] == 'It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway.'
      & df_survey[i, 33] == 'Slightly well') {
    df_survey[i, 33][df_survey[i, 33] == 'Slightly well'] = 3
  } else if (df_survey[i, 32] == 'It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway.'
             & df_survey[i, 33] == 'Very well') {
    df_survey[i, 33][df_survey[i, 33] == 'Very well'] = 4
  } else if (df_survey[i, 32] == 'When I make plans, I am almost certain that I can make them work.'
             & df_survey[i, 33] == 'Slightly well') {
    df_survey[i, 33][df_survey[i, 33] == 'Slightly well'] = 1
  } else if (df_survey[i, 32] == 'When I make plans, I am almost certain that I can make them work.'
             & df_survey[i, 33] == 'Very well') {
    df_survey[i, 33][df_survey[i, 33] == 'Very well'] = 2
  }
}


# item 7

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 34] == 'Many times we might just as well decide what to do by flipping a coin.'
      & df_survey[i, 35] == 'Slightly well') {
    df_survey[i, 35][df_survey[i, 35] == 'Slightly well'] = 3
  } else if (df_survey[i, 34] == 'Many times we might just as well decide what to do by flipping a coin.'
             & df_survey[i, 35] == 'Very well') {
    df_survey[i, 35][df_survey[i, 35] == 'Very well'] = 4
  } else if (df_survey[i, 34] == 'In my case, getting what I want has little or nothing to do with luck.'
             & df_survey[i, 35] == 'Slightly well') {
    df_survey[i, 35][df_survey[i, 35] == 'Slightly well'] = 1
  } else if (df_survey[i, 34] == 'In my case, getting what I want has little or nothing to do with luck.'
             & df_survey[i, 35] == 'Very well') {
    df_survey[i, 35][df_survey[i, 35] == 'Very well'] = 2
  }
}


# item 8

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 36] == 'Who gets to be boss often depends on who was lucky enough to be in the right place first.'
      & df_survey[i, 37] == 'Slightly well') {
    df_survey[i, 37][df_survey[i, 37] == 'Slightly well'] = 3
  } else if (df_survey[36] == 'Who gets to be boss often depends on who was lucky enough to be in the right place first.'
             & df_survey[i, 37] == 'Very well') {
    df_survey[i, 37][df_survey[i, 37] == 'Very well'] = 4
  } else if (df_survey[i, 36] == 'Getting people to do the right thing depends upon ability; luck has little or nothing to do with it.'
             & df_survey[i, 37] == 'Slightly well') {
    df_survey[i, 37][df_survey[i, 37] == 'Slightly well'] = 1
  } else if (df_survey[i, 36] == 'Getting people to do the right thing depends upon ability; luck has little or nothing to do with it.'
             & df_survey[i, 37] == 'Very well') {
    df_survey[i, 37][df_survey[i, 37] == 'Very well'] = 2
  }
}

# item 9

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 38] == "Most people don't realize the extent to which their lives are controlled by accidental happenings."
      & df_survey[i, 39] == 'Slightly well') {
    df_survey[i, 39][df_survey[i, 39] == 'Slightly well'] = 3
  } else if (df_survey[38] == "Most people don't realize the extent to which their lives are controlled by accidental happenings."
             & df_survey[i, 39] == 'Very well') {
    df_survey[i, 39][df_survey[i, 39] == 'Very well'] = 4
  } else if (df_survey[i, 38] == 'There is really no such thing as "luck."'
             & df_survey[i, 39] == 'Slightly well') {
    df_survey[i, 39][df_survey[i, 39] == 'Slightly well'] = 1
  } else if (df_survey[i, 38] == 'There is really no such thing as "luck."'
             & df_survey[i, 39] == 'Very well') {
    df_survey[i, 39][df_survey[i, 39] == 'Very well'] = 2
  }
}


# item 10

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 40] == 'In the long run, the bad things that happen to us are balanced by the good ones.'
      & df_survey[i, 41] == 'Slightly well') {
    df_survey[i, 41][df_survey[i, 41] == 'Slightly well'] = 3
  } else if (df_survey[40] == 'In the long run, the bad things that happen to us are balanced by the good ones.'
             & df_survey[i, 41] == 'Very well') {
    df_survey[i, 41][df_survey[i, 41] == 'Very well'] = 4
  } else if (df_survey[i, 40] == 'Most misfortunes are the result of lack of ability, ignorance, laziness, or all three.'
             & df_survey[i, 41] == 'Slightly well') {
    df_survey[i, 41][df_survey[i, 41] == 'Slightly well'] = 1
  } else if (df_survey[i, 40] == 'Most misfortunes are the result of lack of ability, ignorance, laziness, or all three.'
             & df_survey[i, 41] == 'Very well') {
    df_survey[i, 41][df_survey[i, 41] == 'Very well'] = 2
  }
}


# item 11

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 42] == 'Many times I feel that I have little influence over the things that happen to me.'
      & df_survey[i, 43] == 'Slightly well') {
    df_survey[i, 43][df_survey[i, 43] == 'Slightly well'] = 3
  } else if (df_survey[42] == 'Many times I feel that I have little influence over the things that happen to me.'
             & df_survey[i, 43] == 'Very well') {
    df_survey[i, 43][df_survey[i, 43] == 'Very well'] = 4
  } else if (df_survey[i, 42] == 'It is impossible for me to believe that chance or luck plays an important role in my life.'
             & df_survey[i, 43] == 'Slightly well') {
    df_survey[i, 43][df_survey[i, 43] == 'Slightly well'] = 1
  } else if (df_survey[i, 42] == 'It is impossible for me to believe that chance or luck plays an important role in my life.'
             & df_survey[i, 43] == 'Very well') {
    df_survey[i, 43][df_survey[i, 43] == 'Very well'] = 2
  }
}


df_survey <- subset(df_survey, select = c(1:21, 23, 25, 27, 
                                          29, 31, 33, 35, 37, 39, 41, 43:47))


write.table(df_survey, file = "Survey.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")






