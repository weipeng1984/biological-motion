# Packages
library(car)
library(reshape2)
library(lmerTest)

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = TRUE)

df_wide = dcast(fw + de + du ~ mask, data = df, value.var = "c", mean)

mask = factor(1:3)
idata = data.frame(mask)

mod = lm(cbind(high.dots, low.dots, middle.dots) ~ fw + de, data = df_wide)

summary(mod)




