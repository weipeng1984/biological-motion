# This is to calculate R-square

# read data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

model = lm(c ~ fw + de, data = df)

summary(model)$r.squared
