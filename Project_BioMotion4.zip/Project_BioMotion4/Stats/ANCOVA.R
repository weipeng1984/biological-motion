# ANCOVA
library(tidyverse)
library(ggplot2)
library(car)
library(lme4)
library(lmerTest)
library(afex)
library(ez) 
library(tidyverse)
library(lsmeans)
library(magrittr)
library(emmeans)
library(WRS2)
library(pastecs)
library(ggpubr)
library(rstatix)
library(reshape)
library(psych)
library(multcompView)
library(FSA)
library(phia)
library(cowplot)
library(jtools)
library(ggbeeswarm)

# loading the data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

# plot the data

ggplot(df, aes(y = res, x = group, fill = group)) + 
  geom_violin(trim = FALSE) + geom_boxplot(width = 0.1, fill = "white")+
  labs(title = "Plot of Uncomfortable",x = "group", y = "uncom")+
  theme_minimal() + stat_summary(fun.y = median, geom = "point",
                               size = 2, color = "black")
# center the covariate

df$fwi = scale(df$fwi, center = TRUE, scale = TRUE)
df$fw = scale(df$fw, center = TRUE, scale = TRUE)
df$de = scale(df$de, center = TRUE, scale = TRUE)
df$du = scale(df$du, center = TRUE, scale = TRUE)
df$covid = scale(df$covid, center = TRUE, scale = TRUE)
attach(df)

########################################################################
# ANCONA 

# Summary statistics

df %>%
  group_by(Mask, Group) %>%
  get_summary_stats(Dprime, type = "mean_sd")
# Visualization

bxp = ggboxplot(
  df, x = "Mask", y = "Dprime",
  color = "Group", palette = "jco"
)

bxp

# check outliers

df %>%
  group_by(Mask, Group) %>%
  identify_outliers(Dprime)

# Normality assumption

df %>%
  group_by(Mask, Group) %>%
  shapiro_test(Dprime)

# QQ plot

ggqqplot(df, "Dprime", ggtheme = theme_bw()) +
  facet_grid(Mask ~ Group)
# In the situation where the assumptions are not met, 
# you could consider running the two-way repeated measures 
# ANOVA on the transformed or performing a robust ANOVA test using the WRS2 R package.
# Homogneity of variance assumption

df %>%
  group_by(Mask) %>%
  levene_test(Dprime ~ Group)
# There was homogeneity of variances, as assessed by Levene's test (p > 0.05).


# Homogeneity of co-variances assumption

box_m(df[, "Dprime", drop = FALSE], df$Group)

# perform ANOVA using afex

aov.out = aov_ez(id = "id",
                  dv = "c", covariate = c('fw', 'de', 'du'),
                  within = c("mask"), factorize = FALSE, 
                  data = df, anova_table = list(es = "pes", correction = "none"))

aov.out$Anova
summary(aov.out)
knitr::kable(nice(aov.out))


# interaction plot

interaction.plot(x.factor = df$mask, trace.factor = df$group, 
                 response = df$rt, fun = mean, 
                 type = "b", legend = TRUE, 
                 xlab = "Mask", ylab="Time", trace.label = 'Group',
                 pch=c(19,17), col = c("red", "green"))



