

# reading detection results

df_detection_res <- read.csv(file.choose(), header = TRUE, sep = ',')

# reading ID March results to get the valid session id

MyData <- read.csv(file.choose(), header = TRUE, sep = ',')

attach(df_detection_res)

df_detection_res <- subset(df_detection_res, df_detection_res$Session.id 
                           %in% MyData$Session_ID)

write.table(df_detection_res, file = "Detection.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

################################################################################
# seperation: to split the results by session number

df_detection_res <- read.csv('Detection.csv', header = TRUE, sep = ',')

for (i in 1:length(MyData$Sub_ID)) {
  subset(df_detection_res, df_detection_res$Session.id == MyData$Session_ID[i])
  write.table(subset(df_detection_res, df_detection_res$Session.id
                     == MyData$Session_ID[i])[, c(1, 3, 7, 12, 19, 31)],
              file = paste0('sub', i, '.csv'), sep = ",", col.names = TRUE,
              row.names = FALSE, qmethod = "double")
}

#################################################################################
# calculate the number of trials

library(dplyr)

Sub_ID_less180 <- data.frame(Sub_ID = double(), Session_ID = double(), 
                             trialnumber = double(), 
                             stringsAsFactors = FALSE)
for (i in 1:length(MyData$Sub_ID)) {
  df_detection_res <- read.csv(paste0('sub', i, ".csv"), header = TRUE, 
                               sep = ",")
  if (length(df_detection_res$Session.id) < 180) {
    Sub_ID_less180[i, 1] <- paste0('sub', i)
    Sub_ID_less180[i, 2] <- df_detection_res[1, 1]
    Sub_ID_less180[i, 3] <- length(df_detection_res$Session.id)
  }
}

Sub_ID_less180 <- na.omit(Sub_ID_less180)

write.table(Sub_ID_less180, file = "Sub_ID_less180.csv", sep = ",", 
            col.names = TRUE,
            row.names = FALSE, qmethod = "double")

##########################################################################
# batch calculate the accuracy

acc_total<- data.frame(Sub_ID = character(), Session_ID = double(),
                       acc_total = double(), stringsAsFactors = FALSE)

library('dplyr')

for (i in 1:length(MyData$Sub_ID)) {
  df <- read.csv(paste0('sub', i, '.csv'), header = TRUE, sep = ",")
  h <- 0
  for (j in 1:length(df$Session.id)) {
    if (df[j, 4] == 0 & df[j, 6] == 'Walker') {
      h <- h + 1
    } else if (df[j, 4] == 1 & df[j, 6] == 'No Walker') {
      h <- h + 1
    }
  }
  acc_total[i, 1] <- paste0('sub', i)
  acc_total[i, 2] <- df[1, 1]
  acc_total[i, 3] <- scales::percent(h / length(df$Session.id))
}

# acc_total <- na.omit(acc_total)
write.table(acc_total,
            file = paste0('Sub', '_Acc_total', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE,
            qmethod = "double")







