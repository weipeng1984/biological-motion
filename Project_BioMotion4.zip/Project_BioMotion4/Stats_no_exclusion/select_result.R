# selection based on exclusion result

# read stats data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# read final valid ID (id_list after exclusion based on PLD and RDK)

MyData = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

df = subset(df, df$Prolific %in% MyData$Prolific)

write.table(df, file = paste0('Condition_88_sdt_Stats_exclusion', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
