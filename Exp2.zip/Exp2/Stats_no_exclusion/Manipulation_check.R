# This is to do manipulation check
library(car)
library(knitr)
library(apa)
library(ggplot2)

df_exp = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_ctrl = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)


freewill = stack(list(exp = df_exp$fw, ctrl = df_ctrl$fw))
determinism = stack(list(exp = df_exp$de, ctrl = df_ctrl$de))
dualism = stack(list(exp = df_exp$du, ctrl = df_ctrl$du))


# Levene's Test for Homogeneity of Variance

leveneTest(values~ind, freewill)
leveneTest(values~ind, determinism)
leveneTest(values~ind, dualism)
leveneTest(values~ind, total)


# for free will subscale
t_apa(t_test(df_exp$fw, df_ctrl$fw, var.equal = FALSE))
t.test(df_exp$fw, df_ctrl$fw, var.equal = FALSE)

# for determinism subscale
t_apa(t_test(df_exp$de, df_ctrl$de, var.equal = TRUE))
t.test(df_exp$de, df_ctrl$de, var.equal = TRUE)

# for dualism subscale
t_apa(t_test(df_exp$du, df_ctrl$du, var.equal = FALSE))
t.test(df_exp$du, df_ctrl$du, var.equal = FALSE)

# descriptive data - free will

library(dplyr)
# Summarize data by groups
fw = freewill %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(fw, digits = 2)

# descriptive data - determinism

# Summarize data by groups
de = determinism %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(de, digits = 2)

# descriptive data - dualism

# Summarize data by groups
du = dualism %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(du, digits = 2)


#################################################################
# now we plotting

# for free will 

fw = ggplot(freewill, aes(x = ind, y = values, fill = ind)) + 
  geom_violin(trim = FALSE) + 
  geom_boxplot(width = 0.1, fill = "white") + 
  labs(title = "Plot of free will by group", x = "Group", y = "Score of the free will")
fw + scale_fill_brewer(palette = "Dark2") + theme_minimal()

# for determinism
de = ggplot(determinism, aes(x = ind, y = values, fill = ind)) + 
  geom_violin(trim = FALSE) + 
  geom_boxplot(width = 0.1, fill = "white") + 
  labs(title = "Plot of determinism by group", x = "Group", y = "Score of the determinism")
de + scale_fill_brewer(palette = "Dark2") + theme_minimal()

# dualism

du = ggplot(dualism, aes(x = ind, y = values, fill = ind)) + 
  geom_violin(trim = FALSE) + 
  geom_boxplot(width = 0.1, fill = "white")+
  labs(title="Plot of dualism by group", x = "Group", y = "Score of the dualism")
du + scale_fill_brewer(palette = "Dark2") + theme_minimal()



