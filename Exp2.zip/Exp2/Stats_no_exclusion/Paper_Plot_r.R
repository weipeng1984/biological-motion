
# This is to plot scatter figure
# V.V Peng

library(ggplot2)
library(gridExtra)
library(Hmisc)
library(grid)
library(lattice)
library(latticeExtra)

# read data
df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

# Try to plot the prediction

model_fw = lm(dprime ~ fw, data = df)

model_de = lm(dprime ~ de, data = df)

model_du = lm(dprime ~ du, data = df)

# P1: free will

pred.int = predict(model_fw, interval = "prediction")

df_fw = cbind(df, pred.int)

p1 = ggplot(df_fw, aes(fw, dprime)) + geom_point() + xlab("Belief in free will") + ylab("Sensitivity") + 
    stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                  face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                  axis.title.x = element_text(color = 'black', family = 'Arial',
                                                              face = 'bold', size = 18, hjust = 0.5, angle = 0))

# p2: determinism

pred.int = predict(model_de, interval = "prediction")

df_de = cbind(df, pred.int)

p2 = ggplot(df_de, aes(de, dprime)) + geom_point() + xlab("Belief in determinism") + ylab("Sensitivity") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# p3: dualism

pred.int = predict(model_du, interval = "prediction")

df_du = cbind(df, pred.int)

p3 = ggplot(df_du, aes(du, dprime)) + geom_point() + xlab("Belief in dualism") + ylab("Sensitivity") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# dev.cur()
# dev.off()
pushViewport(viewport(layout = grid.layout(2, 2)))
print(p1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1)) 
print(p2, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
print(p3, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))


##############################################################################################


# Try to plot the prediction

model_fw = lm(c ~ fw, data = df)

model_de = lm(c ~ de, data = df)

model_du = lm(c ~ du, data = df)

# P1: free will

pred.int = predict(model_fw, interval = "prediction")

df_fw = cbind(df, pred.int)

p1 = ggplot(df_fw, aes(fw, c)) + geom_point() + xlab("Belief in free will") + ylab("Liberal ← Response bias → Conservative") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# p2: determinism

pred.int = predict(model_de, interval = "prediction")

df_de = cbind(df, pred.int)

p2 = ggplot(df_de, aes(de, c)) + geom_point() + xlab("Belief in determinism") + ylab("Liberal ← Response bias → Conservative") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# p3: dualism

pred.int = predict(model_du, interval = "prediction")

df_du = cbind(df, pred.int)

p3 = ggplot(df_du, aes(du, c)) + geom_point() + xlab("Belief in dualism") + ylab("Liberal ← Response bias → Conservative") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# dev.cur()
# dev.off()
pushViewport(viewport(layout = grid.layout(2, 2)))
print(p1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1)) 
print(p2, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
print(p3, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))

###############################################################################
# Special case for experiment 2


# read data
df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

# Try to plot the prediction

model_fw = lm(dprime ~ fw, data = df)

model_de = lm(dprime ~ de, data = df)

model_du = lm(dprime ~ du, data = df)

# P1: free will

pred.int = predict(model_fw, interval = "prediction")

df_fw = cbind(df, pred.int)

p1 = ggplot(df_fw, aes(fw, dprime)) + geom_point(aes(color = group, shape = group)) + 
  stat_smooth(method = lm, aes(color = group, fill = group)) + 
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) #+ theme_classic()

p1 = p1 + xlab("Belief in free will") + ylab("Sensitivity") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0), 
        legend.text = element_text(size = 14), legend.title = element_text(size = 14))

# P2: determinism

pred.int = predict(model_de, interval = "prediction")

df_de = cbind(df, pred.int)

p2 = ggplot(df_de, aes(de, dprime)) + geom_point(aes(color = group, shape = group)) + 
  stat_smooth(method = lm, aes(color = group, fill = group)) + 
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) #+ theme_classic()

p2 = p2 + xlab("Belief in determinism") + ylab("Sensitivity") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
        axis.title.x = element_text(color = 'black', family = 'Arial',
                                    face = 'bold', size = 18, hjust = 0.5, angle = 0), 
        legend.text = element_text(size = 14), legend.title = element_text(size = 14))

# P3: dualism

pred.int = predict(model_du, interval = "prediction")

df_du = cbind(df, pred.int)

p3 = ggplot(df_du, aes(du, dprime)) + geom_point(aes(color = group, shape = group)) + 
  stat_smooth(method = lm, aes(color = group, fill = group)) + 
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) #+ theme_classic()

p3 = p3 + xlab("Belief in dualism") + ylab("Sensitivity") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
        axis.title.x = element_text(color = 'black', family = 'Arial',
                                    face = 'bold', size = 18, hjust = 0.5, angle = 0), 
        legend.text = element_text(size = 14), legend.title = element_text(size = 14))

# dev.cur()
# dev.off()
pushViewport(viewport(layout = grid.layout(2, 2)))
print(p1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1)) 
print(p2, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
print(p3, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))

#####################################################################################

# Try to plot the prediction

model_fw = lm(c ~ fw, data = df)

model_de = lm(c ~ de, data = df)

model_du = lm(c ~ du, data = df)

# P1: free will
pred.int = predict(model_fw, interval = "prediction")

df_fw = cbind(df, pred.int)

p1 = ggplot(df_fw, aes(fw, c)) + geom_point(aes(color = group, shape = group)) + 
  stat_smooth(method = lm, aes(color = group, fill = group)) + 
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) #+ theme_classic()

p1 = p1 + xlab("Belief in free will") + ylab("Liberal ← Response bias → Conservative") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
        axis.title.x = element_text(color = 'black', family = 'Arial',
                                    face = 'bold', size = 18, hjust = 0.5, angle = 0), 
        legend.text = element_text(size = 14), legend.title = element_text(size = 14))

# P2: determinism
pred.int = predict(model_de, interval = "prediction")

df_de = cbind(df, pred.int)

p2 = ggplot(df_de, aes(de, c)) + geom_point(aes(color = group, shape = group)) + 
  stat_smooth(method = lm, aes(color = group, fill = group)) + 
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) #+ theme_classic()

p2 = p2 + xlab("Belief in determinism") + ylab("Liberal ← Response bias → Conservative") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
        axis.title.x = element_text(color = 'black', family = 'Arial',
                                    face = 'bold', size = 18, hjust = 0.5, angle = 0), 
        legend.text = element_text(size = 14), legend.title = element_text(size = 14))

# P3: dualism
pred.int = predict(model_du, interval = "prediction")

df_du = cbind(df, pred.int)

p3 = ggplot(df_du, aes(du, c)) + geom_point(aes(color = group, shape = group)) + 
  stat_smooth(method = lm, aes(color = group, fill = group)) + 
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) #+ theme_classic()

p3 = p3 + xlab("Belief in dualism") + ylab("Liberal ← Response bias → Conservative") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
        axis.title.x = element_text(color = 'black', family = 'Arial',
                                    face = 'bold', size = 18, hjust = 0.5, angle = 0), 
        legend.text = element_text(size = 14), legend.title = element_text(size = 14))

# dev.cur()
# dev.off()
pushViewport(viewport(layout = grid.layout(2, 2)))
print(p1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1)) 
print(p2, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
print(p3, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))
