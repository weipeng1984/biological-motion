# ANCOVA
library(tidyverse)
library(ggplot2)
library(car)
library(lme4)
library(lmerTest)
library(afex)
library(ez) 
library(tidyverse)
library(lsmeans)
library(magrittr)
library(emmeans)
library(WRS2)
library(pastecs)
library(ggpubr)
library(rstatix)
library(reshape)
library(psych)
library(multcompView)
library(FSA)
library(phia)
library(cowplot)
library(jtools)
library(ggbeeswarm)

# loading the data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

# perform ANOVA using afex

aov.out = aov_ez(id = "id",
                  dv = "c", covariate = c('fw', 'de', 'du'),
                  within = c("mask"), between = c("group"), factorize = FALSE, 
                  data = df, anova_table = list(es = "pes", correction = "none"))

aov.out$Anova
summary(aov.out)
knitr::kable(nice(aov.out))


# interaction plot

interaction.plot(x.factor = df$mask, trace.factor = df$group, 
                 response = df$rt, fun = mean, 
                 type = "b", legend = TRUE, 
                 xlab = "Mask", ylab="Time", trace.label = 'Group',
                 pch=c(19,17), col = c("red", "green"))



