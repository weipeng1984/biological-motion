# Packages
library(car)
library(reshape2)
library(lmerTest)

# Sum coding

options(contrasts = c("contr.sum", "contr.poly"))

# Read data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = TRUE)

attach(df)

# Unique ID

df$id2 = factor(ifelse(df$group == "exp", paste(df$id, "b", sep = ""), df$id))

# ANCOVA (reproduces aov_ez)

df_wide = dcast(id2 + group + fw + de + du ~ mask, data = df, value.var = "dprime", mean)

mask = factor(1:3)
idata = data.frame(mask)

mod = lm(cbind(high.dots, low.dots, middle.dots) ~ group + fw + de + du, data = df_wide)
summary(mod)

