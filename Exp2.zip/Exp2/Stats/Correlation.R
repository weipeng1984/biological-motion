# this is for scatter plot

df <- read.csv(file.choose(), header = TRUE, sep = ',')
attach(df)
df$beta <- log10(df$beta)
#df$beta <- log10(df$beta)
library("ggplot2")
library("ggpubr")
library('here')
library("dplyr")
library('see')
library('BayesFactor')
library('tidyverse')

# check normality

shapiro.test(df$dprime)


A <- ggscatter(df, x = "fw", y = "dprime", 
               add = "reg.line", conf.int = TRUE, 
               cor.coef = TRUE, cor.method = "pearson",
               xlab = "Free Will", ylab = "Sensitivity")
B <- ggscatter(df, x = "de", y = "dprime", 
               add = "reg.line", conf.int = TRUE, 
               cor.coef = TRUE, cor.method = "pearson",
               xlab = "Determinism", ylab = "Sensitivity")
C <- ggscatter(df, x = "du", y = "dprime",
               add = "reg.line", conf.int = TRUE,
               cor.coef = TRUE, cor.method = "pearson",
              xlab = "Dualism", ylab = "Sensitivity")

theme_set(theme_bw() + theme(legend.position = "top"))

figure <- ggarrange(A, B, C, labels = c("A", "B", "C"),
                    ncol = 2, nrow = 2)
figure


# Non-parametric method 

model <- cor.test(df$AQ, df$FTV, method="pearson")

result <- correlationBF(df$AQ, df$FTV, rscale = "medium", method="pearson")

# Bayes factor
describe_posterior(result)
bayesfactor(result)
plot(bayesfactor(result)) +
  scale_fill_pizza()

