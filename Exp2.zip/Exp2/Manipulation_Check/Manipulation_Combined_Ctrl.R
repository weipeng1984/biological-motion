
# this is to add ip and combine all the files into one

library(tidyverse)

# batch reading the data

filenames <- list.files(path = getwd(),
                        pattern = 'Manipulation_CtrlGrp_+.*csv')

# creating prolific id

Prolific_ID <-substr(filenames, 22, 45)

# batch add missing ip
for (i in 1:length(Prolific_ID)) {
  MyData <- read.csv(paste0('Manipulation_CtrlGrp_', Prolific_ID[i], '.csv'), 
                     header = TRUE, sep = ',')
  if (ncol(MyData) < 10) {
    MyData <- add_column(MyData, ip = 'no_ip', .before = 'prolific' )
    write.table(MyData,
                file = paste0('Manipulation_CtrlGrp_', Prolific_ID[i],'.csv'), 
                sep = ',', col.names = TRUE,
                row.names = FALSE,
                qmethod = 'double')
  }
}

# define empty data frame
df_manipulation <- data.frame(view_history = character(), rt = double(), trial_type = character(),
                              trial_index = double(), time_elapsed = double(), 
                              internal_node_id = character(), ip = character(),
                              prolific = character(), write = character(), summary = character(),
                              stringsAsFactors = FALSE)
# combine rows 
for (i in 1:length(Prolific_ID)) {
  MyData <- read.csv(paste0('Manipulation_CtrlGrp_', Prolific_ID[i], '.csv'), 
                     header = TRUE, sep = ',')
  df_manipulation[i, ] <- MyData[1, 1:10]
}

# write into tables

write.table(df_manipulation,
            file = paste0('Manipulation_Combined_CtrlGrp','.csv'), 
            sep = ',', col.names = TRUE,
            row.names = FALSE,
            qmethod = 'double')
