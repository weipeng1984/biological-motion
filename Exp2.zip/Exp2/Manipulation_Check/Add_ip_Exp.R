

library(tidyverse)

# batch reading the data

filenames <- list.files(path = getwd(),
                        pattern = 'Manipulation_ExpGrp_+.*csv')

# creating prolific id

Prolific_ID <-substr(filenames, 21, 44)
num <- length(Prolific_ID)

# batch 
for (i in 1:num) {
  MyData <- read.csv(paste0('Manipulation_ExpGrp_', Prolific_ID[i], '.csv'), 
                     header = TRUE, sep = ',')
  if (ncol(MyData) < 10) {
    MyData <- add_column(MyData, ip = 'no_ip', .before = 'prolific' )
    write.table(MyData,
                file = paste0('Manipulation_ExpGrp_', Prolific_ID[i],'.csv'), 
                sep = ',', col.names = TRUE,
                row.names = FALSE,
                qmethod = 'double')
  }
}

# This function is designed to extract value from the string.

extract_value <- function(s) {
  if (length(s) == 16) {
    reading_time <- readr::parse_number(s[4]) + readr::parse_number(s[8]) + readr::parse_number(s[12]) 
    + readr::parse_number(s[16])
  } else if (length(s) == 12) {
    reading_time <- readr::parse_number(s[4]) + readr::parse_number(s[8]) + readr::parse_number(s[12])
  } else if (length(s) == 8) {
    reading_time <- readr::parse_number(s[4]) + readr::parse_number(s[8])
  } else {
    reading_time <- readr::parse_number(s[4])
  }
  return(reading_time)
}

# Create data frame

Time_Stats<- data.frame(Prolific_ID = character(), IP = double(), Reading_Time = double(), 
                        stringsAsFactors = FALSE)

# batch reading the data

filenames <- list.files(path = getwd(),
                        pattern = 'Manipulation_ExpGrp_+.*csv')

# creating prolific id

Prolific_ID <-substr(filenames, 21, 44)
num <- length(Prolific_ID)

# batch 
for (i in 1:num) {
  MyData <- read.csv(paste0('Manipulation_ExpGrp_', Prolific_ID[i], '.csv'), 
                     header = TRUE, sep = ',')
  stringlist <- as.character(MyData$view_history)
  s = unlist(strsplit(stringlist, split = ',', fixed = TRUE))
  reading_time <- extract_value(s)
  Time_Stats[i, 1] <- paste0(Prolific_ID[i])
  Time_Stats[i, 2] <- MyData[1, 7]
  Time_Stats[i, 3] <- reading_time
}

# Time_Stats <- na.omit(Time_Stats)

write.table(Time_Stats,
            file = paste0('Time_Stats_Exp','.csv'), sep = ',', col.names = TRUE,
            row.names = FALSE,
            qmethod = 'double')






















