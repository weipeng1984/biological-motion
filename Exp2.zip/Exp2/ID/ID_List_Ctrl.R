# this is to match the ID between platforms 

library(tidyverse)

ID <- data.frame(Sub_ID = character(), Session_ID = double(), Response_ID = double(),
                Prolific_ID = character(), IP = character(), Reading_Time = double(),
                stringsAsFactors = FALSE)
# reading survey data
df_survey <- read.csv(file.choose(), header = TRUE, sep = ',')
# reading session data
df_detection <- read.csv(file.choose(), header = TRUE, sep = ',')
# reading the manipulation data
df_manipulation <- read.csv(file.choose(), header = TRUE, sep = ',')
# Change the column names of survey data


names(df_survey)[1] <- 'Response_ID'
names(df_survey)[8] <- 'IP'
names(df_survey)[9] <- 'Prolific_ID'
names(df_survey)[10] <- 'Education'
names(df_survey)[11] <- 'Gender'
names(df_survey)[12] <- 'Age'
names(df_survey)[13] <- 'Country'
names(df_survey)[14] <- 'F01'
names(df_survey)[15] <- 'F02'
names(df_survey)[16] <- 'F03'
names(df_survey)[17] <- 'F04'
names(df_survey)[18] <- 'F05'
names(df_survey)[19] <- 'F06'
names(df_survey)[20] <- 'F07'
names(df_survey)[21] <- 'F08'
names(df_survey)[22] <- 'F09'
names(df_survey)[23] <- 'F10'
names(df_survey)[24] <- 'F11'
names(df_survey)[25] <- 'F12'
names(df_survey)[26] <- 'F13'
names(df_survey)[27] <- 'F14'
names(df_survey)[28] <- 'F15'
names(df_survey)[29] <- 'Ctrl_Q'
names(df_survey)[30] <- 'Corona01'
names(df_survey)[31] <- 'Corona02'
names(df_survey)[32] <- 'Corona03'

df_survey <- subset(df_survey, select = c(1, 8:32))

# change column names of detection data

names(df_detection)[1] <- 'Session_ID'
names(df_detection)[2] <- 'Prolific_ID'
names(df_detection)[8] <- 'IP'
names(df_detection)[9] <- 'Country_by_IP'

df_detection <- subset(df_detection, select = c(1:6, 8:9))

# identify duplicate 

df_survey$IP[duplicated(df_survey$IP)]
df_survey$Prolific_ID[duplicated(df_survey$Prolific_ID)]


df_detection$IP[duplicated(df_detection$IP)]
df_detection$Prolific_ID[duplicated(df_detection$Prolific_ID)]


df_manipulation$prolific[duplicated(df_manipulation$prolific)]


# starting matching
for (i in 1:dim(df_survey)[1]) {
   for (j in 1:dim(df_detection)[1]) {
      if (df_survey[i, 2] == df_detection[j, 7]) {
          ID[i, 3] <- df_survey[i, 1]
          ID[i, 2] <- df_detection[j, 1]
          ID[i, 4] <- df_survey[i, 3]
          ID[i, 5] <- df_survey[i, 2]
      }
   }
}

# unify answer option

gender <- as.character(df_survey$Gender)

for (i in gender) {
  if (i == 'female') {
    gender[gender == 'female'] = 'f'
  } else if (i == 'Female') {
    gender[gender == 'Female'] = 'f'
  } else if (i == 'F') {
    gender[gender == 'F'] = 'f'
  } else if (i == 'FEMALE') {
    gender[gender == 'FEMALE'] = 'f'
  } else if (i == 'Feminino') {
    gender[gender == 'Feminino'] = 'f'
  } else if (i == 'Femmina') {
    gender[gender == 'Femmina'] = 'f'
  } else if (i == 'Famale') {
    gender[gender == 'Famale'] = 'f'
  } else if (i == 'male') {
    gender[gender == 'male'] = 'm'
  } else if (i == 'Male') {
    gender[gender == 'Male'] = 'm'
  } else if (i == 'MALE') {
    gender[gender == 'MALE'] = 'm'
  } else if (i == 'man') {
    gender[gender == 'man'] = 'm'
  } else if (i == 'men') {
    gender[gender == 'men'] = 'm'
  } else if (i == 'women') {
    gender[gender == 'women'] = 'f'
  } else if (i == 'Male ') {
    gender[gender == 'Male '] = 'm'
  } else if (i == 'Female ') {
    gender[gender == 'Female '] = 'f'
  } else if (i == 'Fem') {
    gender[gender == 'Fem'] = 'f'
  } else {
    print('Please check all the levels manually!')
  }
  #return(gender)
}

df_survey$Gender <- gender

# now dealing with questions

ctrl_q <- as.character(df_survey$Ctrl_Q)
num <- length(ctrl_q)
num <- c(1:num)

for (j in num) {
  ctrl_q[j] <-ifelse(ctrl_q[j] == 'In the postscript, Francis Crick outlines the difficulties involved in the scientific investigation of consciousness.', '100%', '0%')
}

df_survey$Ctrl_Q <- ctrl_q

# calculate the free will beliefs (don't reverse the Determinism subscale)
# dimension of the dataframe


for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_survey)[2]) {
    if (df_survey[i, j] == 'Strongly disagree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly disagree'] = 1
    } else if (df_survey[i, j] == 'Disagree') {
      df_survey[i, j][df_survey[i, j] == 'Disagree'] = 2
    } else if (df_survey[i, j] == 'Somewhat disagree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat disagree'] = 3
    } else if (df_survey[i, j] == 'Neither agree nor disagree') {
      df_survey[i, j][df_survey[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df_survey[i, j] == 'Somewhat agree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat agree'] = 5
    } else if (df_survey[i, j] == 'Agree') {
      df_survey[i, j][df_survey[i, j] == 'Agree'] = 6
    } else if (df_survey[i, j] == 'Strongly agree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill <- c(8, 11, 14, 17, 20)
determinism <- c(9, 12, 15, 18, 21)
dualism <- c(10, 13, 16, 19, 22)


# calculating the free will beliefs

df_survey$freewill_total <- rowSums(sapply(df_survey[, freewill], as.numeric))

# calculating the Determinism

df_survey$determinism_total <- rowSums(sapply(df_survey[, determinism], as.numeric))

# calculating the dualism subscale

df_survey$dualism_total <- rowSums(sapply(df_survey[, dualism], as.numeric))

# sum the total score for each participant

df_survey$total_score <- rowSums(sapply(df_survey[, 8:22], as.numeric))



# compute cronbach alpha for whole scale

library(psych)

df_survey$total_alpha[1] <- as.character(alpha(sapply(df_survey[, 8:22], 
                                                      as.numeric))$total[1])

# free will

df_survey$freewill_alpha[1] <- as.character(alpha(sapply(df_survey[, freewill], 
                                                         as.numeric))$total[1])

# determinism

df_survey$determinism_alpha[1] <- as.character(alpha(sapply(df_survey[, determinism], 
                                                            as.numeric))$total[1])

# dualism

df_survey$dualism_alpha[1] <- as.character(alpha(sapply(df_survey[, dualism], 
                                                        as.numeric))$total[1])


# starting to transform the Corona survey

for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_survey)[2]) {
    if (df_survey[i, j] == 'Not at all restrictive') {
      df_survey[i, j][df_survey[i, j] == 'Not at all restrictive'] = 1
    } else if (df_survey[i, j] == 'Slightly restrictive') {
      df_survey[i, j][df_survey[i, j] == 'Slightly restrictive'] = 2
    } else if (df_survey[i, j] == 'Restrictive') {
      df_survey[i, j][df_survey[i, j] == 'Restrictive'] = 3
    } else if (df_survey[i, j] == 'Very restrictive') {
      df_survey[i, j][df_survey[i, j] == 'Very restrictive'] = 4
    } else if (df_survey[i, j] == 'Extremely restrictive') {
      df_survey[i, j][df_survey[i, j] == 'Extremely restrictive'] = 5
    } else if (df_survey[i, j] == 'Not at all affected') {
      df_survey[i, j][df_survey[i, j] == 'Not at all affected'] = 1
    } else if (df_survey[i, j] == 'Slightly affected') {
      df_survey[i, j][df_survey[i, j] == 'Slightly affected'] = 2
    } else if (df_survey[i, j] == 'Affected') {
      df_survey[i, j][df_survey[i, j] == 'Affected'] = 3
    } else if (df_survey[i, j] == 'Very affected') {
      df_survey[i, j][df_survey[i, j] == 'Very affected'] = 4
    } else if (df_survey[i, j] == 'Extremely affected') {
      df_survey[i, j][df_survey[i, j] == 'Extremely affected'] = 5
    } else if (df_survey[i, j] == 'Not at all uncomfortable') {
      df_survey[i, j][df_survey[i, j] == 'Not at all uncomfortable'] = 1
    } else if (df_survey[i, j] == 'Slightly uncomfortable') {
      df_survey[i, j][df_survey[i, j] == 'Slightly uncomfortable'] = 2
    } else if (df_survey[i, j] == 'Neutral') {
      df_survey[i, j][df_survey[i, j] == 'Neutral'] = 3
    } else if (df_survey[i, j] == 'Very uncomfortable') {
      df_survey[i, j][df_survey[i, j] == 'Very uncomfortable'] = 4
    } else if (df_survey[i, j] == 'Extremely uncomfortable') {
      df_survey[i, j][df_survey[i, j] == 'Extremely uncomfortable'] = 5
    }
  }
}

# computing the Corona-survey

corona <- c(24:26)

df_survey$Corona <- rowSums(sapply(df_survey[, corona], as.numeric))

# add multiple column

ID <- cbind(ID, df_survey[, 4:35])

ID[, 39] <- NA
names(ID)[39]<-"Country_by_IP"

# writing the country

# starting matching
for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_detection)[1]) {
    if (df_survey[i, 2] == df_detection[j, 7]) {
      ID[i, 39] <- df_detection[j, 8]
      
    }
  }
}

# sorting the Session_ID by ascending order

ID <- ID[order(ID$Session_ID), ]

for (i in 1:dim(ID)[1]) {
  if (i < 10) {
    ID[i, 1] <- paste0('sub00', i)
  } else if (i >= 10 && i < 100) {
    ID[i, 1] <- paste0('sub0', i)
  } else if (i >= 100) {
    ID[i, 1] <- paste0('sub', i)
  }
}

########################################################################################
# starting marching manipulation data with ID by ip address, 
# first to sort manipulation data


# This function is designed to extract value from the string.

extract_value <- function(s) {
  if (length(s) == 16) {
    reading_time <- readr::parse_number(s[4]) + readr::parse_number(s[8]) + readr::parse_number(s[12]) 
    + readr::parse_number(s[16])
  } else if (length(s) == 12) {
    reading_time <- readr::parse_number(s[4]) + readr::parse_number(s[8]) + readr::parse_number(s[12])
  } else if (length(s) == 8) {
    reading_time <- readr::parse_number(s[4]) + readr::parse_number(s[8])
  } else {
    reading_time <- readr::parse_number(s[4])
  }
  return(reading_time)
}

# Create data frame

Time_Stats<- data.frame(Prolific_ID = character(), IP = double(), Reading_Time = double(), 
                        stringsAsFactors = FALSE)


# extract reading time
for (i in 1:dim(df_manipulation)[1]) {
  stringlist <- as.character(df_manipulation$view_history[i])
  s = unlist(strsplit(stringlist, split = ',', fixed = TRUE))
  reading_time <- extract_value(s)
  Time_Stats[i, 1] <- paste0(df_manipulation$prolific[i])
  Time_Stats[i, 2] <- df_manipulation[i, 7]
  Time_Stats[i, 3] <- reading_time
}

# Merging the ID with Time_Stats
# writing the correct ip to Time_Stats

Time_Stats <- subset(Time_Stats, Time_Stats$Prolific_ID %in% ID$Prolific_ID)

for (i in 1:dim(ID)[1]) {
  for (j in 1:dim(Time_Stats)[1]) {
    if (ID[i, 4] == Time_Stats[j, 1]) {
      #Time_Stats[j, 2] <- ID[i, 5]
      ID[i, 6] <- Time_Stats[j, 3]
    }
  }
}

# remove NA (once I find a 'NA', i will delete the whole row)

ID <- ID[complete.cases(ID), ]

# resorting the Session_ID by ascending order

ID <- ID[order(ID$Session_ID), ]

for (i in 1:dim(ID)[1]) {
  if (i < 10) {
    ID[i, 1] <- paste0('sub00', i)
  } else if (i >= 10 && i < 100) {
    ID[i, 1] <- paste0('sub0', i)
  } else if (i >= 100) {
    ID[i, 1] <- paste0('sub', i)
  }
}


# recheck the duplicated 
ID$IP[duplicated(ID$IP)]
ID$IP[duplicated(ID$Prolific_ID)]
ID$IP[duplicated(ID$Session_ID)]


#############################################################################

# Exclude by reading time & questions
library(data.table)
# ID.2 <- copy(ID)
# ID.2 <- filter(ID.2, ID.2$Reading_Time >= 45000)
# ID.2 <- filter(ID.2, ID.2$Ctrl_Q == '100%')
ID <- filter(ID, ID$Reading_Time >= 45000 & ID$Ctrl_Q == '100%')

# resorting the Session_ID by ascending order

ID <- ID[order(ID$Session_ID), ]

for (i in 1:dim(ID)[1]) {
  if (i < 10) {
    ID[i, 1] <- paste0('sub00', i)
  } else if (i >= 10 && i < 100) {
    ID[i, 1] <- paste0('sub0', i)
  } else if (i >= 100) {
    ID[i, 1] <- paste0('sub', i)
  }
}

write.table(ID, file = "ID_Ctrl.csv", sep = ",", col.names = TRUE,
            row.names = FALSE,
            qmethod = "double")


