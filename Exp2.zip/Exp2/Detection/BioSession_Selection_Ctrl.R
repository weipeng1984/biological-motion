
# This is to do data sorting. try to select the session which we need in the results.
# Session.id is in the original file, while Session_ID is what we created in the ID_List.

# reading detection results

df_detection_res <- read.csv(file.choose(), header = TRUE, sep = ',')

# reading sorting file to get the valid session id -- 'Ctrl_ID'

MyData <- read.csv(file.choose(), header = TRUE, sep = ',')

attach(df_detection_res)
df_detection_res <- subset(df_detection_res, df_detection_res$Session.id 
                           %in% MyData$Session_ID)
write.table(df_detection_res, file = "Detection_Ctrl.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

################################################################################
# separation: to split the control results by session number

df_detection_res <- read.csv('Detection_Ctrl.csv', header = TRUE, sep = ',')

for (i in 1:length(MyData$Sub_ID)) {
  subset(df_detection_res, df_detection_res$Session.id == MyData$Session_ID[i])
  write.table(subset(df_detection_res, df_detection_res$Session.id
                     == MyData$Session_ID[i])[, c(1, 3, 7, 12, 19, 31)],
              file = paste0('sub', i, '_Ctrl', '.csv'), sep = ",", col.names = TRUE,
              row.names = FALSE, qmethod = "double")
}


#################################################################################
# calculate the number of trials

library(dplyr)

Sub_ID_Ctrl_less180 <- data.frame(Sub_ID = double(), Session_ID = double(), 
                                  trialnumber = double(), 
                                  stringsAsFactors = FALSE)
for (i in 1:149) {
  df_detection_res <- read.csv(paste0('sub', i, '_Ctrl', ".csv"), header = TRUE, 
                               sep = ",")
  if (length(df_detection_res$Session.id) < 180) {
    Sub_ID_Ctrl_less180[i, 1] <- paste0('sub', i)
    Sub_ID_Ctrl_less180[i, 2] <- df_detection_res[1, 1]
    Sub_ID_Ctrl_less180[i, 3] <- length(df_detection_res$Session.id)
  }
}

Sub_ID_Ctrl_less180 <- na.omit(Sub_ID_Ctrl_less180)

write.table(Sub_ID_Ctrl_less180, file = "Sub_ID_Ctrl_less180.csv", sep = ",", 
            col.names = TRUE,
            row.names = FALSE, qmethod = "double")


#############################################################################

# This is to calculate index of SDT
# Create data frame

sdt <- data.frame(Sub_ID = character(),
                 n_hit = double(), n_fa = double(), n_miss = double(), n_cr = double(),
                 rt = double(), acc_43 = double(), sum = double(), 
                 stringsAsFactors = FALSE)

for (i in 1:149) {
  # calculate the mean response time and its' standard deviation
  df <- read.csv(paste0('sub', i, '_Ctrl', '.csv'), header = TRUE, sep = ",")
  # mean rt
  rt <- mean(filter(df, Scrambled.Mask == 43)$Response.Time)
  # counter the number of hit 
  h = 0
  for (j in 1:length(df$Session.id)) {
    if ((df[j, 4] == 0 & df[j, 6] == 'Walker') & df[j, 5] == 43) {
      h = h + 1
    }
  }
  # counter the number of false alarm
  f = 0
  for (j in 1:length(df$Session.id)) {
    if ((df[j, 4] == 1 & df[j, 6] == 'Walker') & df[j, 5] == 43) {
      f = f + 1
    }
  }
  # counter the number of miss
  m = 0
  for (j in 1:length(df$Session.id)) {
    if ((df[j, 4] == 0 & df[j, 6] == 'No Walker') & df[j, 5] == 43) {
      m = m + 1
    }
  }
  # counter the number of correct rejection
  c = 0
  for (j in 1:length(df$Session.id)) {
    if ((df[j, 4] == 1 & df[j, 6] == 'No Walker') & df[j, 5] == 43) {
      c = c + 1
    }
  }
  sum = h + f + m + c
  sdt[i, 2] <- h
  sdt[i, 3] <- f
  sdt[i, 4] <- m
  sdt[i, 5] <- c
  sdt[i, 6] <- rt
  sdt[i, 8] <- sum
  sdt[i, 7] <- scales::percent((h + c) / sum)
  sdt[i, 1] <- paste0('sub', i)
}

sdt <- na.omit(sdt)
write.table(sdt,
            file = paste0('sub_condition_43_Ctrl', '_sdt', '.csv'), sep = ",", 
            col.names = TRUE,
            row.names = FALSE, qmethod = "double")

#################################################################################

library(psycho)

# calculate different index

df <- read.csv('sub_condition_43_Ctrl_sdt.csv', header = TRUE, sep = ',')

df <- data.frame(Sub_ID = c(df$Sub_ID),
                 n_hit = c(df$n_hit),
                 n_fa = c(df$n_fa), 
                 n_miss = c(df$n_miss),
                 n_cr = c(df$n_cr),
                 rt = c(df$rt))
indices <- psycho::dprime(df$n_hit, df$n_fa, df$n_miss, df$n_cr)

df <- cbind(df, indices)
df<- cbind(df, sdt[7])
df <- cbind(MyData, df[2:12])

write.table(df, file = "Condition_43_sdt_Ctrl_Stats.csv", sep = ",", col.names = TRUE,
            row.names = FALSE,
            qmethod = "double")


